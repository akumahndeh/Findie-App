import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonIcon,
  IonImg,
  IonRow,
  IonSlide,
  IonSlides,
  IonText,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import React from "react";
import TextContent from "../components/TextArea";
import { arrowBack } from "ionicons/icons";
import "../css/TextArea.css";
import img from "../img/img.jpeg";

const Main: React.FC<{ title: string }> = (props) => {
  let message = `Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum iste nostrum labore! Suscipit officia necessitatibus fugiat, eaque, ab harum perspiciatis provident hic doloribus iste vel soluta reprehenderit. Provident, ducimus nulla.`;

  return (
    <>
      <IonHeader translucent={true}>
        <IonToolbar className="tb-h">
          <IonRow>
            <IonIcon size="large" color="light" className="mx-2" icon={arrowBack}></IonIcon>
            <IonTitle size="large">{props.title}</IonTitle>
          </IonRow>
        </IonToolbar>
      </IonHeader>
        <IonToolbar className="slide-toolbar">
          <IonSlides className="slides">
            <IonSlide>Transcript</IonSlide>
            <IonSlide>lorem</IonSlide>
            <IonSlide>ipsum</IonSlide>
            <IonSlide>dolor</IonSlide>
            <IonSlide>lorem</IonSlide>
            <IonSlide>ipsum</IonSlide>
            <IonSlide>dolor</IonSlide>
            <IonSlide>lorem</IonSlide>
            <IonSlide>ipsum</IonSlide>
            <IonSlide>dolor</IonSlide>
            <IonSlide>lorem</IonSlide>
            <IonSlide>ipsum</IonSlide>
            <IonSlide>dolor</IonSlide>
          </IonSlides>
        </IonToolbar>
      <IonContent>
        <TextContent text={message}></TextContent>
        <IonTitle size="large" className="text-subtitle">
          Lorem Title
        </IonTitle>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Lorem</IonCardTitle>
            <IonCardSubtitle>Ipsum Dolor</IonCardSubtitle>
          </IonCardHeader>
          <IonImg src={img}></IonImg>
          <IonCardContent>
            <IonText>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit.
              Perferendis fugiat architecto sed deleniti dolores laudantium
              omnis, sint ab eius provident adipisci inventore autem eaque
              voluptas. Consectetur dicta suscipit laborum molestiae.
            </IonText>
          </IonCardContent>
        </IonCard>
        <TextContent text={message}></TextContent>
        <IonTitle size="large" className="text-subtitle">
          Lorem Title
        </IonTitle>
        <TextContent text={message}></TextContent>
      </IonContent>
    </>
  );
};

export default Main;
