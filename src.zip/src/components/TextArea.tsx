import { IonText } from "@ionic/react";
import React from "react";

import "../css/TextArea.css";

const TextContent: React.FC<{ text: string }> = (props) => {
  return (
      <div className="text-content">
          <IonText>{props.text}</IonText>
      </div>
  );
};

export default TextContent;
